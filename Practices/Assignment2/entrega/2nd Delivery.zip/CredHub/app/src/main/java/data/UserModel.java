package data;

import android.provider.*;

public class UserModel {

    public static final String TABLE_NAME ="User";

    public static final String Description = "Description";
    public static final String Username = "Username";
    public static final String Password = "Password";

}
